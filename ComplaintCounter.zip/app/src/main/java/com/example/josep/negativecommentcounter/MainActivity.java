package com.example.josep.negativecommentcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Timer;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {


    private String newComplaint="";   //to store new input
    private Button newButton;       //to create new log
    private EditText complaintEditText; //to enter new input
    private TextView complaintTextView; //to display new input
    private TextView sushiTextView; //to display result
    private TextView targetTimeTextView; //to display the target Time

    //create a counter
    public int counter=0;
    public int sushiCounter=0;

    //create timer variables
    long time1=0, time2=0, time3=0;
    DateFormat dateFormat=new SimpleDateFormat("aahh:mm");
    SimpleDateFormat df=new SimpleDateFormat("hh:mmaa");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //get references
        complaintEditText=(EditText)findViewById(R.id.complaintEditText);
        newButton=(Button)findViewById(R.id.newButton);
        complaintTextView=(TextView)findViewById(R.id.complaintTextView);
        sushiTextView=(TextView)findViewById(R.id.sushiTextView);
        targetTimeTextView=(TextView)findViewById(R.id.targetTimeTextView);

        //onclick listener
        newButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                //some function
                Calendar cal=Calendar.getInstance(); //create instance
                counter++; //increment per instance
                newComplaint+=dateFormat.format(cal.getTime())+" "
                        +complaintEditText.getText().toString()+"\n\n"; //stored the value in EditText to String
                complaintTextView.setText(newComplaint); //display the string

                //record click time
                if(time1==0){
                    time1=System.currentTimeMillis(); //record the time 1
                    //target time calculator
                    cal.add(Calendar.MINUTE, 120);
                    String targetTime=df.format(cal.getTime());
                    targetTimeTextView.setText(targetTime+"   <---get her to complain!!"); //display the target time

                }
                else if(time2==0)time2=System.currentTimeMillis();
                else if(time3==0){
                    time3=System.currentTimeMillis();
                    //if time3-time1 is within 2 hr window, display the win msg
                    if(threeComplaintsInTwoHours(time1, time3)==true)
                        sushiTextView.setText("Big Bean gets "+sushiCounter+" sushi dinner HO\nRERUN APP");
                    else
                        sushiTextView.setText("Sorry boss, she took time making complaints this time");

                }


            }//end onClickListener
        });

    }//end main method

    //need to use this function in a bit!!!
    public boolean threeComplaintsInTwoHours(long time1, long time3)
    {

        if(((time3-time1)/1000)<7200){
            counter=0; //reset counter to 0
            time1=0;
            time2=0;
            time3=0;
            sushiCounter++; //increment sushicounter
            return true;
        }

        else {
            counter=0;
            time1=0;
            time2=0;
            time3=0;
            return false;
        }

    }//end method

}//end class
